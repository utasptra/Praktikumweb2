<?php

// Mencetak angka 1 sampai 10 menggunakan for
for ($i = 1; $i <= 10; $i++) {
    echo $i . "<br>";
}

// Membuat sebuah array
$buah = ["apel", "mangga", "jeruk", "pisang"];

// Menggunakan foreach untuk menampilkan setiap elemen pada array
foreach ($buah as $b) {
    echo $b . "<br>";
}

?>