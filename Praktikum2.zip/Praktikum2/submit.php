<?php

$username = $_POST['username'];
$password = $_POST['password'];

echo "<h1>Selamat datang $username</h1>";